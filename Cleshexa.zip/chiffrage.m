HH = 'Coucou'
ke = str2double(HH);
% Get the Plain Text Value with the tag pl
HH = findobj(gcf,'Tag','pl');
pl = get(HH,'String');
%Operation of Encryption
if ke>26
    cipher = ['Wrong Key Used'];
    cipher=cipher;
    HH = findobj(gcf,'Tag','cipher'); 
set(HH,'String',cipher) 
end
C=pl+ke;
l=find(C>122);
C(l)=C(l)-26;
l=find(C>90);
l=find(C(l)<97);
C(l)=C(l)-26;
l=find(pl==32);
C(l)=32;
cipher=char(C);
HH = findobj(gcf,'Tag','cipher'); 
set(HH,'String',cipher) 