function t=z(zeta,a)
t=1-exp((-zeta/sqrt(1-zeta^2))*sin(6.28*sqrt(1-zeta^2)*a)+cos(6.28*sqrt(1-zeta^2)*a));