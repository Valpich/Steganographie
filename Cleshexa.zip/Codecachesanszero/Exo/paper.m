function sortie = paper(nul,mauvais )
    a=nul+255;
    b=mauvais-128;
    sortie=a/b;
end

 